### Example: MPI

We showcase an MPI wrapper for facilitating memory transfers between devices

### Compiling the Example

```bash
make
```

### Usage

```
> ./main
```
