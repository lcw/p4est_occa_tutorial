#ifndef OCCA_ARRAY_HEADER
#define OCCA_ARRAY_HEADER

#include <occa/array/array.hpp>

#endif
