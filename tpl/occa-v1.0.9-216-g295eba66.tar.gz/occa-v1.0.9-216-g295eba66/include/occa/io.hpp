#ifndef OCCA_IO_HEADER
#define OCCA_IO_HEADER

#include <occa/io/cache.hpp>
#include <occa/io/fileOpener.hpp>
#include <occa/io/lock.hpp>
#include <occa/io/utils.hpp>

#endif
