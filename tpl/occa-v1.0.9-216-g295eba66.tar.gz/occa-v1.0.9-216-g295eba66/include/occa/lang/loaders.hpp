#ifndef OCCA_LANG_LOADERS_HEADER
#define OCCA_LANG_LOADERS_HEADER

#include <occa/lang/loaders/attributeLoader.hpp>
#include <occa/lang/loaders/structLoader.hpp>
#include <occa/lang/loaders/typeLoader.hpp>
#include <occa/lang/loaders/variableLoader.hpp>

#endif
