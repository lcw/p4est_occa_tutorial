#include <occa/defines.hpp>

#if OCCA_HIP_ENABLED
#  ifndef OCCA_MODES_HIP_HEADER
#  define OCCA_MODES_HIP_HEADER

#include <occa/modes/hip/utils.hpp>

#  endif
#endif
