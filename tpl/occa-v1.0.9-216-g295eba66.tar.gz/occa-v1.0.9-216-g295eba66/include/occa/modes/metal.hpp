#include <occa/defines.hpp>

#if OCCA_METAL_ENABLED
#  ifndef OCCA_MODES_METAL_HEADER
#  define OCCA_MODES_METAL_HEADER

// No utility methods yet

#  endif
#endif
